var manageStudentTable;
var studentSectionTable = {};
var base_url = $("#base_url").val();

$(document).ready(function () {
  var request = $("#request").text();

  $("#topStudentMainNav").addClass("active");

  if (request == "addst") {
    $("#addStudentNav").addClass("active");

    $("#registerDate").calendarsPicker({
      dateFormat: "yyyy-mm-dd",
    });

    $("#dob").calendarsPicker({
      dateFormat: "yyyy-mm-dd",
    });

    $("#photo").fileinput({
      overwriteInitial: true,
      maxFileSize: 1500,
      showClose: false,
      showCaption: false,
      showBrowse: false,
      browseOnZoneClick: true,
      removeLabel: "",
      removeIcon: '<i class="glyphicon glyphicon-remove"></i>',
      removeTitle: "Cancel or reset changes",
      elErrorContainer: "#kv-avatar-errors-2",
      msgErrorClass: "alert alert-block alert-danger",
      defaultPreviewContent:
        '<img src="' +
        base_url +
        'assets/images/default/default_avatar.png" alt="Your Avatar" style="width:208px;height:200px;"><h6 class="text-muted">Click to select</h6>',
      layoutTemplates: { main2: "{preview} {remove} {browse}" },
      allowedFileExtensions: ["jpg", "png", "gif", "JPG", "PNG", "GIF"],
    });

    // change on the class
    $("#className")
      .unbind("change")
      .bind("change", function () {
        var class_id = $(this).val();
        $("#sectionName").load(
          base_url + "student/fetchClassSection/" + class_id
        );
      });

    /*
     * submit the create student form
     */
    $("#createStudentForm")
      .unbind("submit")
      .bind("submit", function () {
        $("#messages").html("");

        var form = $(this);
        var url = form.attr("action");
        var type = form.attr("method");
        var formData = new FormData($(this)[0]);

        $.ajax({
          url: url,
          type: type,
          data: formData,
          dataType: "json",
          cache: false,
          contentType: false,
          processData: false,
          async: false,
          success: function (response) {
            if (response.success == true) {
              $("#messages").html(
                '<div class="alert alert-success alert-dismissible" role="alert">' +
                  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                  response.messages +
                  "</div>"
              );

              $(".form-group")
                .removeClass("has-error")
                .removeClass("has-success");
              $(".text-danger").remove();
              clearForm();
            } else {
              if (response.messages instanceof Object) {
                $.each(response.messages, function (index, value) {
                  var key = $("#" + index);

                  key
                    .closest(".form-group")
                    .removeClass("has-error")
                    .removeClass("has-success")
                    .addClass(value.length > 0 ? "has-error" : "has-success")
                    .find(".text-danger")
                    .remove();

                  key.after(value);
                });
              } else {
                $("#messages").html(
                  '<div class="alert alert-warning alert-dismissible" role="alert">' +
                    '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                    response.messages +
                    "</div>"
                );
              }
            } // /else
          }, // /success
        }); // /ajax

        return false;
      });
  } // /add individual student
  else if (request == "bulkst") {
    $("#addBulkStudentNav").addClass("active");
    $("#createBulkForm")
      .unbind("submit")
      .bind("submit", function () {
        var form = $(this);
        var url = form.attr("action");
        var type = form.attr("method");

        $.ajax({
          url: url,
          type: type,
          data: form.serialize(),
          dataType: "json",
          success: function (response) {
            if (response.success == true) {
              $("#messages").html(
                '<div class="alert alert-success alert-dismissible" role="alert">' +
                  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                  response.messages +
                  "</div>"
              );

              $(".form-group")
                .removeClass("has-error")
                .removeClass("has-success");
              $(".text-danger").remove();

              $('input[type="text"]').val("");
              $("#createBulkForm")[0].reset();
            } else {
              if (response.messages instanceof Object) {
                $.each(response.messages, function (index, value) {
                  var key = $("#" + index);

                  key
                    .closest(".form-group")
                    .removeClass("has-error")
                    .removeClass("has-success")
                    .addClass(value.length > 0 ? "has-error" : "has-success")
                    .find(".text-danger")
                    .remove();

                  key.after(value);
                });
              } else {
                $("#messages").html(
                  '<div class="alert alert-warning alert-dismissible" role="alert">' +
                    '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                    response.messages +
                    "</div>"
                );
              }
            } // /else
          }, // /.sucess
        }); // /.ajax

        return false;
      });
  } // /add bulk student
  else if (request == "mgst") {
    $("#manageStudentNav").addClass("active");

    var classSideBar = $(".classSideBar").attr("id");
    var class_id = classSideBar.substring(7);

    getClassSection(class_id);
  } // /manage student table
});

/*
 *----------------------------
 * get class section function
 *----------------------------
 */
function getClassSection(classId = null) {
  if (classId) {
    $(".list-group-item").removeClass("active");
    $("#classId" + classId).addClass("active");
    $.ajax({
      url: base_url + "studentPayment/getClassSectionTab/" + classId,
      type: "post",
      dataType: "json",
      success: function (response) {
        $("#result").html(response.html);

        manageStudentTable = $("#manageStudentTable").DataTable({
          ajax: "studentPayment/fetchStudentByClass/" + classId,
          order: [],
        });

        /*
         *-------------------------------------
         * retrives from the getclassectiontab
         * function as a json format
         * and stores the section table into
         * the object
         *-------------------------------------
         */
        $.each(response.sectionData, function (index, value) {
          index += 1;
          studentSectionTable["studentTable" + index] = $(
            "#manageStudentTable" + index
          ).DataTable({
            ajax:
              "studentPayment/fetchStudentByClassAndSection/" +
              value.class_id +
              "/" +
              value.section_id,
            order: [],
          });
        });
      }, // /success
    }); // /ajax
  }
}

function clearForm() {
  $('input[type="text"]').val("");
  $("select").val("");
  $("#sectionName").html('<option value="">Select Class</option>');

  $(".fileinput-remove-button").click();
}

/*
 *-------------------------------
 * update student's info function
 *-------------------------------
 */
function updateStudent(studentId = null) {
  if (studentId) {
    let userLevel = $("#userlevel").val();
    if (userLevel == 1) {
      document.getElementById("basicTransportFee").removeAttribute("readonly");
      document.getElementById("transportFee").removeAttribute("readonly");
      document.getElementById("basicMonthlyFee").removeAttribute("readonly");
      document.getElementById("monthlyFee").removeAttribute("readonly");
      document.getElementById("totalAmount").removeAttribute("readonly");
      document.getElementById("totalPayableAmount").removeAttribute("readonly");
      document.getElementById("dueAmount").removeAttribute("readonly");
    }
    $("#editRegisterDate").calendarsPicker({
      dateFormat: "yyyy-mm-dd",
    });

    $("#editDob").calendarsPicker({
      dateFormat: "yyyy-mm-dd",
    });

    $("#editPhoto").fileinput({
      overwriteInitial: true,
      maxFileSize: 1500,
      showClose: false,
      showCaption: false,
      showBrowse: false,
      browseOnZoneClick: true,
      removeLabel: "",
      removeIcon: '<i class="glyphicon glyphicon-remove"></i>',
      removeTitle: "Cancel or reset changes",
      elErrorContainer: "#kv-avatar-errors-2",
      msgErrorClass: "alert alert-block alert-danger",
      defaultPreviewContent:
        '<img src="' +
        base_url +
        'assets/images/default/edit_avatar.png" alt="Your Avatar" style="width:208px;height:200px;"><h6 class="text-muted">Click to select</h6>',
      layoutTemplates: { main2: "{preview} {remove} {browse}" },
      allowedFileExtensions: ["jpg", "png", "gif", "JPG", "PNG", "GIF"],
    });

    $(".form-group").removeClass("has-error").removeClass("has-success");
    $(".text-danger").remove();
    // photo
    $("#edit-upload-image-message").html("");
    $(".fileinput-remove-button").click();

    // information
    $("#edit-personal-student-message").html("");

    $.ajax({
      url: base_url + "studentPayment/fetchStudentData/" + studentId,
      type: "post",
      dataType: "json",
      success: function (response) {
        $("#paymentId").val(response.payment_name_id);
        $("#paymentName").val(response.name);
        $("#startDate").val(response.start_date);
        $("#durationPayment").val(response.duration);
        $("#durationPayment").attr({ min: response.duration });
        $("#endDate").val(response.end_date);
        $("#className").val(response.class_name);
        $("#section").val(response.section_name);
        $("#rollNo").val(response.rollno);
        $("#studentName").val(response.student_name);
        $("#totalAmount").val(response.total_amount);
        $("#totalPayableAmount").val(response.total_payableamount);
        $("#previousPaid").val(response.paid_amount);

        $("#examinationFee").val(response.p_examination_fee);
        $("#developmentFee").val(response.p_development_fee);
        $("#tie").val(response.p_tie);
        $("#belt").val(response.p_belt);
        $("#diary").val(response.p_diary);
        $("#basicTransportFee").val(response.transport_fee);
        $("#transportFee").val(response.payabletransportfee);
        $("#lateFine").val(response.late_fine);
        $("#basicMonthlyFee").val(response.monthly_fee);
        $("#monthlyFee").val(response.payablemonthlyfee);
        $("#studentPayDate").val();
        $("#paidAmount").val();
        $("#dueAmount").val(response.due_amount);
        $("#discount").val(response.discount);
        $("#session").val(response.session);
        $("#paymentType").val(response.payment_type);
        $("#status").val(response.status);

        $("#durationPayment")
          .unbind("change")
          .bind("change", function () {
            var a = Number($("#durationPayment").val());
            var CurrentDate = new Date($("#startDate").val());
            CurrentDate.setMonth(CurrentDate.getMonth() + a);
            CurrentDate.setDate(
              0,
              CurrentDate.getMonth,
              CurrentDate.getFullYear
            );
            $("#endDate").val(CurrentDate.toISOString().split("T")[0]);
            calMonthFee();
            calTransportFee();
            calculateTotalAmount();
          });
        function calMonthFee() {
          if ($("#duration").val() == "") {
            return false;
          } else if ($("#startDate").val() == "") {
            return false;
          } else {
            var finalMonthlyFee = 0;
            finalMonthlyFee =
              Number($("#basicMonthlyFee").val()) *
              Number($("#durationPayment").val());
            $("#monthlyFee").val(finalMonthlyFee);
          }
        }
        function calTransportFee() {
          if ($("#duration").val() == "") {
            return false;
          } else if ($("#startDate").val() == "") {
            return false;
          } else {
            var finalTransportFee = 0;
            finalTransportFee =
              Number($("#basicTransportFee").val()) *
              Number($("#durationPayment").val());
            $("#transportFee").val(finalTransportFee);
          }
        }
        $("#studentPayDate").calendarsPicker({
          dateFormat: "yyyy-mm-dd",
        });
        $("#examinationFee")
          .unbind("change")
          .bind("change", function () {
            calculateTotalAmount();
          });
        $("#tie")
          .unbind("change")
          .bind("change", function () {
            calculateTotalAmount();
            var dueAmount =
              Number($("#totalPayableAmount").val()) -
              Number($("#totalPaid").val());
            $("#dueAmount").val(dueAmount);
          });
        $("#belt")
          .unbind("change")
          .bind("change", function () {
            calculateTotalAmount();
            var dueAmount =
              Number($("#totalPayableAmount").val()) -
              Number($("#totalPaid").val());
            $("#dueAmount").val(dueAmount);
          });
        $("#diary")
          .unbind("change")
          .bind("change", function () {
            calculateTotalAmount();
            var dueAmount =
              Number($("#totalPayableAmount").val()) -
              Number($("#totalPaid").val());
            $("#dueAmount").val(dueAmount);
          });
        $("#transportFee")
          .unbind("change")
          .bind("change", function () {
            calculateTotalAmount();
          });
        $("#lateFine")
          .unbind("change")
          .bind("change", function () {
            calculateTotalAmount();
            var dueAmount =
              Number($("#totalAmount").val()) - Number($("#totalPaid").val());
            $("#dueAmount").val(dueAmount);
          });
        $("#monthlyFee")
          .unbind("change")
          .bind("change", function () {
            calculateTotalAmount();
          });

        $("#discount")
          .unbind("change")
          .bind("change", function () {
            var totalPaid =
              Number($("#totalAmount").val()) - Number($("#discount").val());
            $("#totalPayableAmount").val(totalPaid);
            var totalPaidAmount = Number($("#totalPaid").val());
            if (!totalPaidAmount) {
              var dueAmount =
                Number($("#totalPayableAmount").val()) -
                Number($("#previousPaid").val());
              $("#dueAmount").val(dueAmount);
            } else {
              var dueAmount =
                Number($("#totalPayableAmount").val()) -
                Number($("#totalPaid").val());
              $("#dueAmount").val(dueAmount);
            }
          });

        function calculateTotalAmount() {
          var totalFee =
            Number($("#examinationFee").val()) +
            Number($("#tie").val()) +
            Number($("#belt").val()) +
            Number($("#diary").val()) +
            Number($("#transportFee").val()) +
            Number($("#lateFine").val()) +
            Number($("#monthlyFee").val());
          $("#totalAmount").val(totalFee);
          var discount = Number($("#discount").val());
          if (!discount) {
            $("#totalPayableAmount").val(totalFee);
          } else {
            discountedAmount = totalFee - discount;
            $("#totalPayableAmount").val(discountedAmount);
          }
        }

        $("#paidAmount")
          .unbind("change")
          .bind("change", function () {
            var totalAmount = Number($("#totalAmount").val());
            var totalPayableAmount = Number($("#totalPayableAmount").val());
            if (totalPayableAmount == 0) {
              Number($("#totalPayableAmount").val(totalAmount));
            }

            var totalPaid =
              Number($("#previousPaid").val()) + Number($("#paidAmount").val());
            $("#totalPaid").val(totalPaid);
            var dueAmount =
              Number($("#totalPayableAmount").val()) -
              Number($("#totalPaid").val());
            $("#dueAmount").val(dueAmount);
          });

        $("#editSectionName").load(
          "student/fetchClassSection/" + response.class_id,
          function (i) {
            $("#editSectionName").val(response.section_id);
          }
        );

        $("#student_photo").attr("src", base_url + response.image);

        $("#editClassName")
          .unbind("change")
          .bind("change", function () {
            var class_id = $(this).val();
            $("#editSectionName").load("student/fetchClassSection/" + class_id);
          });

        // submit the teacher information form
        $("#updateStudentInfoForm")
          .unbind("submit")
          .bind("submit", function () {
            var form = $(this);
            var url = form.attr("action");
            var type = form.attr("method");

            $.ajax({
              url: url + "/" + studentId,
              type: type,
              data: form.serialize(),
              dataType: "json",
              success: function (response) {
                if (response.success == true) {
                  $("#edit-personal-student-message").html(
                    '<div class="alert alert-success alert-dismissible" role="alert">' +
                      '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                      response.messages +
                      "</div>"
                  );
                  manageStudentTable.ajax.reload(null, false);
                  clearForm();
                  $("#editStudentModal").modal("hide");

                  //   getClassSection(response.class_id);
                  // refresh the section table
                  $.each(studentSectionTable, function (index, value) {
                    studentSectionTable[index].ajax.reload(null, false);
                  });

                  $(".form-group")
                    .removeClass("has-error")
                    .removeClass("has-success");
                  $(".text-danger").remove();
                } else {
                  if (response.messages instanceof Object) {
                    $.each(response.messages, function (index, value) {
                      var key = $("#" + index);

                      key
                        .closest(".form-group")
                        .removeClass("has-error")
                        .removeClass("has-success")
                        .addClass(
                          value.length > 0 ? "has-error" : "has-success"
                        )
                        .find(".text-danger")
                        .remove();

                      key.after(value);
                    });
                  } else {
                    $("#edit-personal-student-message").html(
                      '<div class="alert alert-warning alert-dismissible" role="alert">' +
                        '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                        response.messages +
                        "</div>"
                    );
                  }
                } // /else
              }, // /success
            }); // /ajax
            return false;
          }); // /submit the teacher information form

        // submit the teacher photo form
        $("#updateStudentPhotoForm")
          .unbind("submit")
          .bind("submit", function () {
            var form = $(this);
            var formData = new FormData($(this)[0]);
            var url = form.attr("action") + "/" + studentId;
            var type = form.attr("method");

            $.ajax({
              url: url,
              type: type,
              data: formData,
              dataType: "json",
              cache: false,
              contentType: false,
              processData: false,
              async: false,
              success: function (response) {
                if (response.success == true) {
                  $("#edit-upload-image-message").html(
                    '<div class="alert alert-success alert-dismissible" role="alert">' +
                      '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                      response.messages +
                      "</div>"
                  );

                  manageStudentTable.ajax.reload(null, false);

                  // refresh the section table
                  $.each(studentSectionTable, function (index, value) {
                    studentSectionTable[index].ajax.reload(null, false);
                  });

                  $(".form-group")
                    .removeClass("has-error")
                    .removeClass("has-success");
                  $(".text-danger").remove();

                  $(".fileinput-remove-button").click();

                  $.ajax({
                    url: "student/fetchStudentData/" + studentId,
                    type: "post",
                    dataType: "json",
                    success: function (response) {
                      $("#student_photo").attr("src", "../" + response.image);
                    },
                  });
                } else {
                  $("#edit-upload-image-message").html(
                    '<div class="alert alert-warning alert-dismissible" role="alert">' +
                      '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                      response.messages +
                      "</div>"
                  );
                } // /else
              }, // /success
            }); // /ajax
            return false;
          }); // /submit the teacher photo form
      }, // /success
    }); // /ajax
  } // /if
}

function printStudentPay(id = null) {
  $("#print-student-result").load(
    base_url + "accounting/printstudentPaymentInfo/" + id,
    function () {
      $("#studentPayDate").calendarsPicker({
        dateFormat: "yyyy-mm-dd",
      });

      $("#updateStudentPayForm")
        .unbind("submit")
        .bind("submit", function () {
          var form = $(this);
          var url = form.attr("action");
          var type = form.attr("method");

          $.ajax({
            url: url + "/" + id,
            type: type,
            data: form.serialize(),
            dataType: "json",
            success: function (response) {
              if (response.success == true) {
                $("#update-student-payment-message").html(
                  '<div class="alert alert-success alert-dismissible" role="alert">' +
                    '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                    response.messages +
                    "</div>"
                );

                $(".form-group")
                  .removeClass("has-error")
                  .removeClass("has-success");
                $(".text-danger").remove();

                manageStudentPayTable.ajax.reload(null, false);
              } else {
                $.each(response.messages, function (index, value) {
                  var key = $("#" + index);

                  key
                    .closest(".form-group")
                    .removeClass("has-error")
                    .removeClass("has-success")
                    .addClass(value.length > 0 ? "has-error" : "has-success")
                    .find(".text-danger")
                    .remove();

                  key.after(value);
                });
              }
            }, // /.success
          }); // /ajax

          return false;
        }); // /.udpate student pay form submit
    }
  ); // /result of the update student payment form
}

//update Student Status
function updateStudentStatus(id = null) {
  // console.log(base_url);
  $("#edit-student-status-result").load(
    base_url + "PrintAdmissionSlip/fetchStudentStatusInfo/" + id + "/" + 2,
    function () {
      $("#updateStudentStatusForm")
        .unbind("submit")
        .bind("submit", function () {
          var form = $(this);
          var url = form.attr("action");
          var type = form.attr("method");

          $.ajax({
            url: url + "/" + id,
            type: type,
            data: form.serialize(),
            dataType: "json",
            success: function (response) {
              if (response.success == true) {
                $("#update-student-status-message").html(
                  '<div class="alert alert-success alert-dismissible" role="alert">' +
                    '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                    response.messages +
                    "</div>"
                );

                $(".form-group")
                  .removeClass("has-error")
                  .removeClass("has-success");
                $(".text-danger").remove();
                setTimeout(location.reload.bind(location), 1000);
                manageStudentPayTable.ajax.reload(null, false);
              } else {
                $.each(response.messages, function (index, value) {
                  var key = $("#" + index);

                  key
                    .closest(".form-group")
                    .removeClass("has-error")
                    .removeClass("has-success")
                    .addClass(value.length > 0 ? "has-error" : "has-success")
                    .find(".text-danger")
                    .remove();

                  key.after(value);
                });
              }
            }, // /.success
          }); // /ajax

          return false;
        });
    }
  );
}
/*
 *-------------------------------
 * remove student's info function
 *-------------------------------
 */

/*
 *-------------------------------
 * remove student's info function
 *-------------------------------
 */
function removeStudent(studentId = null) {
  if (studentId) {
    $("#removeStudentBtn")
      .unbind("click")
      .bind("click", function () {
        $.ajax({
          url: "student/remove/" + studentId,
          type: "post",
          dataType: "json",
          success: function (response) {
            if (response.success == true) {
              $("#messages").html(
                '<div class="alert alert-success alert-dismissible" role="alert">' +
                  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                  response.messages +
                  "</div>"
              );

              manageStudentTable.ajax.reload(null, false);

              // refresh the section table
              $.each(studentSectionTable, function (index, value) {
                studentSectionTable[index].ajax.reload(null, false);
              });

              $("#removeStudentModal").modal("hide");
            } else {
              $("#messages").html(
                '<div class="alert alert-warning alert-dismissible" role="alert">' +
                  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                  response.messages +
                  "</div>"
              );
            }
          }, // /success
        }); // /ajax
      }); // /remove student btn clicked
  } // /if
}

function removeStudentPay(id = null) {
  if (id) {
    $("#removeStudentPayBtn")
      .unbind("click")
      .bind("click", function () {
        $.ajax({
          url: base_url + "PrintAdmissionSlip/removeStudentPay/" + id,
          type: "post",
          dataType: "json",
          success: function (response) {
            if (response.success == true) {
              $("#removeStudentPay").modal("hide");

              $("#remove-stu-payment-message").html(
                '<div class="alert alert-success alert-dismissible" role="alert">' +
                  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                  response.messages +
                  "</div>"
              );
              setTimeout(location.reload.bind(location), 1000);
              manageStudentPayTable.ajax.reload(null, false);
            } else {
              $("#remove-stu-payment-message").html(
                '<div class="alert alert-warning alert-dismissible" role="alert">' +
                  '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                  response.messages +
                  "</div>"
              );
            }
          }, // /.success
        }); // /.ajax
      }); // /.remove button clicked
  } // /.if
}

/*
 *-------------------------------
 * add row student's info function
 *-------------------------------
 */
function addRow() {
  var countTotalTR = $("#addBulkStudentTable tbody tr").length;
  var countId = 0;

  if (countTotalTR <= 0) {
    countId = 1;
  } else {
    var lastRowNumber = $("#addBulkStudentTable tbody tr:last").attr("id");
    var countId = lastRowNumber.substring(3);
    countId = Number(countId) + 1;
  } // /else

  $.ajax({
    url: base_url + "student/getAppendBulkStudentRow/" + countId,
    type: "post",
    success: function (response) {
      if ($("#addBulkStudentTable tbody tr").length > 1) {
        $("#addBulkStudentTable tbody tr:last").after(response);
      } else {
        $("#addBulkStudentTable tbody").append(response);
      }
    }, // /success
  }); // ajax
}

/*
 *-------------------------------
 * remove row studnt's info function
 *-------------------------------
 */
function removeRow(rowId = null) {
  if (rowId) {
    $("#row" + rowId)
      .fadeOut()
      .remove();
  }
}

/*
 *-------------------------------
 * gets the class's section info function
 *-------------------------------
 */
function getSelectClassSection(rowId = null) {
  if (rowId) {
    var class_id = $("#bulkstclassName" + rowId).val();
    $("#bulkstsectionName" + rowId).load(
      base_url + "student/fetchClassSection/" + class_id
    );
  }
}
