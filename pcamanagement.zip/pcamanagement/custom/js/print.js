
$(document).ready(function(){
	$("#print_button1").click(function(){
		var mode = 'iframe'; // popup
		var close = mode == "popup";
		var options = { mode : mode, popClose : close};
		$("div.wrapper").printArea( options );
	});
	 $("#print_button2").click(function(){
		var mode = 'iframe'; // popup
		var close = mode == "popup";
		var options = { mode : mode, popClose : close};
		$("div.content").printArea( options );
	});
});

